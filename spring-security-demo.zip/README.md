# Spring Security 学生成绩管理示例

这是一个 Spring Boot + Spring Security + Thymeleaf + MySQL 示例项目，包含学生成绩表格管理、账号分组和基于角色的访问控制。

## 运行前准备

1. 在 MySQL 中执行初始化脚本：

```sql
SOURCE src/main/resources/sql/init.sql;
```

2. 使用 JDK 17 启动项目。

数据库连接配置位于 `src/main/resources/application.properties`，默认 MySQL 用户名为 `root`，密码为 `123`。

## 初始账号

| 用户名 | 密码 | 分组 | 权限 |
| --- | --- | --- | --- |
| teacher | 123 | 老师 | 查看、添加、修改、删除学生成绩 |
| student | 123 | 学生 | 只能查看学生成绩 |
| damin | 123 | 管理员 | 管理账号和用户分组，并拥有成绩管理权限 |

项目启动时会自动检查并补齐这三个账号。成绩表为空时会生成一批随机成绩，并固定补一条姓名为 `student` 的成绩数据；`student` 登录后进入成绩页会自动跳转并高亮对应行。

## 页面

- 登录页：http://localhost:8080/login
- 成绩管理页：http://localhost:8080/scores
- 管理员页：http://localhost:8080/admin/main
- 账号和用户分组管理：http://localhost:8080/admin/users

成绩表格支持按学号、姓名、科目、成绩、考试、学期、日期排序。
