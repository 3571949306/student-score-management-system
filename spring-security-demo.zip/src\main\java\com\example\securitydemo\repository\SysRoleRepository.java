package com.example.securitydemo.repository;

import com.example.securitydemo.entity.SysRole;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SysRoleRepository extends JpaRepository<SysRole, Long> {

    Optional<SysRole> findByName(String name);

    @Query(value = "select r.* from sys_role r " +
            "inner join sys_user_role ur on r.id = ur.role_id " +
            "inner join sys_user u on u.id = ur.user_id " +
            "where u.username = :username order by r.id", nativeQuery = true)
    List<SysRole> findRolesByUsername(@Param("username") String username);
}
