package com.example.securitydemo.config;

import com.example.securitydemo.entity.StudentScore;
import com.example.securitydemo.entity.SysRole;
import com.example.securitydemo.entity.SysUser;
import com.example.securitydemo.repository.StudentScoreRepository;
import com.example.securitydemo.repository.SysRoleRepository;
import com.example.securitydemo.repository.SysUserRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final SysUserRepository userRepository;
    private final SysRoleRepository roleRepository;
    private final StudentScoreRepository scoreRepository;
    private final JdbcTemplate jdbcTemplate;

    public DataInitializer(SysUserRepository userRepository,
            SysRoleRepository roleRepository,
            StudentScoreRepository scoreRepository,
            JdbcTemplate jdbcTemplate) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.scoreRepository = scoreRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void run(String... args) {
        SysRole teacherRole = ensureRole("ROLE_TEACHER", "老师");
        SysRole studentRole = ensureRole("ROLE_STUDENT", "学生");
        SysRole adminRole = ensureRole("ROLE_ADMIN", "管理员");

        ensureUser("teacher", "123", teacherRole);
        ensureUser("student", "123", studentRole);
        ensureUser("damin", "123", adminRole);
        ensureScores();
    }

    private SysRole ensureRole(String name, String description) {
        return roleRepository.findByName(name).map(role -> {
            role.setDescription(description);
            return roleRepository.save(role);
        }).orElseGet(() -> {
            SysRole role = new SysRole();
            role.setName(name);
            role.setDescription(description);
            return roleRepository.save(role);
        });
    }

    private void ensureUser(String username, String password, SysRole role) {
        SysUser user = userRepository.findByUsername(username).map(existingUser -> {
            existingUser.setPassword(password);
            existingUser.setEnabled(true);
            return userRepository.save(existingUser);
        }).orElseGet(() -> {
            SysUser newUser = new SysUser();
            newUser.setUsername(username);
            newUser.setPassword(password);
            newUser.setEnabled(true);
            return userRepository.save(newUser);
        });

        Integer count = jdbcTemplate.queryForObject(
                "select count(*) from sys_user_role where user_id = ? and role_id = ?",
                Integer.class,
                user.getId(),
                role.getId());
        if (count == null || count == 0) {
            jdbcTemplate.update("insert into sys_user_role (user_id, role_id) values (?, ?)", user.getId(), role.getId());
        }
    }

    private void ensureScores() {
        if (scoreRepository.count() == 0) {
            List<String> names = Arrays.asList("李明", "王芳", "赵强", "陈晓", "刘洋", "周晴");
            List<String> subjects = Arrays.asList("语文", "数学", "英语", "物理", "化学", "生物", "政治", "历史", "地理", "体育");
            Random random = new Random();
            for (int i = 0; i < 12; i++) {
                saveScore(
                        names.get(random.nextInt(names.size())),
                        "2026" + String.format("%03d", random.nextInt(80) + 1),
                        subjects.get(random.nextInt(subjects.size())),
                        randomScore(random),
                        "期中考试",
                        "高一上",
                        LocalDate.of(2026, 4, 20).plusDays(random.nextInt(5)),
                        "系统随机生成");
            }
        }

        if (!scoreRepository.existsByStudentName("student")) {
            saveScore("student", "2026000", "数学", new BigDecimal("128.00"),
                    "期中考试", "高一上", LocalDate.of(2026, 4, 20), "学生账号匹配数据");
        }
    }

    private BigDecimal randomScore(Random random) {
        return BigDecimal.valueOf(8000 + random.nextInt(6501), 2);
    }

    private void saveScore(String studentName,
            String studentNumber,
            String subject,
            BigDecimal score,
            String examName,
            String semester,
            LocalDate examDate,
            String remark) {
        StudentScore studentScore = new StudentScore();
        studentScore.setStudentName(studentName);
        studentScore.setStudentNumber(studentNumber);
        studentScore.setSubject(subject);
        studentScore.setScore(score);
        studentScore.setExamName(examName);
        studentScore.setSemester(semester);
        studentScore.setExamDate(examDate);
        studentScore.setRemark(remark);
        scoreRepository.save(studentScore);
    }
}
