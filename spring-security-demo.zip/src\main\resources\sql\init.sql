CREATE DATABASE IF NOT EXISTS spring_security_demo DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE spring_security_demo;

DROP TABLE IF EXISTS student_score;
DROP TABLE IF EXISTS sys_user_role;
DROP TABLE IF EXISTS sys_role;
DROP TABLE IF EXISTS sys_user;

CREATE TABLE sys_user (
    id BIGINT NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uk_sys_user_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sys_role (
    id BIGINT NOT NULL AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(100),
    PRIMARY KEY (id),
    UNIQUE KEY uk_sys_role_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sys_user_role (
    user_id BIGINT NOT NULL,
    role_id BIGINT NOT NULL,
    PRIMARY KEY (user_id, role_id),
    CONSTRAINT fk_user_role_user FOREIGN KEY (user_id) REFERENCES sys_user (id),
    CONSTRAINT fk_user_role_role FOREIGN KEY (role_id) REFERENCES sys_role (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE student_score (
    id BIGINT NOT NULL AUTO_INCREMENT,
    student_name VARCHAR(50) NOT NULL,
    student_number VARCHAR(30) NOT NULL,
    subject VARCHAR(30) NOT NULL,
    score DECIMAL(5,2) NOT NULL,
    exam_name VARCHAR(50),
    semester VARCHAR(30),
    exam_date DATE,
    remark VARCHAR(200),
    PRIMARY KEY (id),
    KEY idx_student_score_student_number (student_number),
    KEY idx_student_score_subject (subject),
    KEY idx_student_score_score (score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO sys_user (id, username, password, enabled) VALUES
(1, 'teacher', '123', 1),
(2, 'student', '123', 1),
(3, 'damin', '123', 1);

INSERT INTO sys_role (id, name, description) VALUES
(1, 'ROLE_TEACHER', '老师'),
(2, 'ROLE_STUDENT', '学生'),
(3, 'ROLE_ADMIN', '管理员');

INSERT INTO sys_user_role (user_id, role_id) VALUES
(1, 1),
(2, 2),
(3, 3);

INSERT INTO student_score (student_name, student_number, subject, score, exam_name, semester, exam_date, remark) VALUES
('student', '2026000', '数学', 128.00, '期中考试', '高一上', '2026-04-20', '学生账号匹配数据'),
('李明', '2026001', '语文', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('李明', '2026001', '数学', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('王芳', '2026002', '英语', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('王芳', '2026002', '物理', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('赵强', '2026003', '化学', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('赵强', '2026003', '生物', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('陈晓', '2026004', '政治', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('陈晓', '2026004', '历史', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('刘洋', '2026005', '地理', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成'),
('刘洋', '2026005', '体育', ROUND(80 + RAND() * 65, 2), '期中考试', '高一上', '2026-04-20', '随机生成');
