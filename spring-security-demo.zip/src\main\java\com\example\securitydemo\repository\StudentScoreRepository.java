package com.example.securitydemo.repository;

import com.example.securitydemo.entity.StudentScore;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentScoreRepository extends JpaRepository<StudentScore, Long> {

    Optional<StudentScore> findFirstByStudentNameOrderByIdAsc(String studentName);

    boolean existsByStudentName(String studentName);
}
