package com.example.securitydemo.controller;

import com.example.securitydemo.entity.StudentScore;
import com.example.securitydemo.repository.StudentScoreRepository;
import java.util.Arrays;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/scores")
public class StudentScoreController {

    private static final List<String> SUBJECTS = Arrays.asList(
            "语文", "数学", "英语", "物理", "化学", "生物", "政治", "历史", "地理", "体育");
    private static final List<String> SORT_FIELDS = Arrays.asList(
            "studentNumber", "studentName", "subject", "score", "examName", "semester", "examDate");

    private final StudentScoreRepository scoreRepository;

    public StudentScoreController(StudentScoreRepository scoreRepository) {
        this.scoreRepository = scoreRepository;
    }

    @GetMapping
    public String list(@RequestParam(defaultValue = "studentNumber") String sort,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) Long focus,
            Authentication authentication,
            Model model) {
        if (focus == null) {
            return scoreRepository.findFirstByStudentNameOrderByIdAsc(authentication.getName())
                    .map(score -> "redirect:/scores?focus=" + score.getId() + "#score-" + score.getId())
                    .orElseGet(() -> showList(sort, direction, focus, authentication, model));
        }
        return showList(sort, direction, focus, authentication, model);
    }

    private String showList(String sort, String direction, Long focus, Authentication authentication, Model model) {
        String sortField = SORT_FIELDS.contains(sort) ? sort : "studentNumber";
        Sort.Direction sortDirection = "desc".equalsIgnoreCase(direction) ? Sort.Direction.DESC : Sort.Direction.ASC;
        model.addAttribute("scores", scoreRepository.findAll(Sort.by(sortDirection, sortField)));
        model.addAttribute("scoreForm", new StudentScore());
        model.addAttribute("subjects", SUBJECTS);
        model.addAttribute("sort", sortField);
        model.addAttribute("direction", sortDirection.name().toLowerCase());
        model.addAttribute("canEdit", canEdit(authentication));
        model.addAttribute("username", authentication.getName());
        model.addAttribute("formAction", "/scores");
        model.addAttribute("focusId", focus);
        return "scores";
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('TEACHER', 'ADMIN')")
    public String create(@ModelAttribute StudentScore score) {
        scoreRepository.save(score);
        return "redirect:/scores";
    }

    @GetMapping("/{id}/edit")
    @PreAuthorize("hasAnyRole('TEACHER', 'ADMIN')")
    public String edit(@PathVariable Long id, Authentication authentication, Model model) {
        model.addAttribute("scores", scoreRepository.findAll(Sort.by(Sort.Direction.ASC, "studentNumber")));
        model.addAttribute("scoreForm", scoreRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("成绩不存在：" + id)));
        model.addAttribute("subjects", SUBJECTS);
        model.addAttribute("sort", "studentNumber");
        model.addAttribute("direction", "asc");
        model.addAttribute("canEdit", true);
        model.addAttribute("username", authentication.getName());
        model.addAttribute("formAction", "/scores/" + id);
        model.addAttribute("focusId", id);
        return "scores";
    }

    @PostMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER', 'ADMIN')")
    public String update(@PathVariable Long id, @ModelAttribute StudentScore score) {
        score.setId(id);
        scoreRepository.save(score);
        return "redirect:/scores";
    }

    @PostMapping("/{id}/delete")
    @PreAuthorize("hasAnyRole('TEACHER', 'ADMIN')")
    public String delete(@PathVariable Long id) {
        scoreRepository.deleteById(id);
        return "redirect:/scores";
    }

    private boolean canEdit(Authentication authentication) {
        return authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(role -> "ROLE_TEACHER".equals(role) || "ROLE_ADMIN".equals(role));
    }
}
