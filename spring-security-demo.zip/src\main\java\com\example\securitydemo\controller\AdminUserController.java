package com.example.securitydemo.controller;

import com.example.securitydemo.entity.SysRole;
import com.example.securitydemo.entity.SysUser;
import com.example.securitydemo.repository.SysRoleRepository;
import com.example.securitydemo.repository.SysUserRepository;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/users")
public class AdminUserController {

    private final SysUserRepository userRepository;
    private final SysRoleRepository roleRepository;
    private final JdbcTemplate jdbcTemplate;

    public AdminUserController(SysUserRepository userRepository, SysRoleRepository roleRepository, JdbcTemplate jdbcTemplate) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping
    public String list(Authentication authentication, Model model) {
        addModel(authentication, model, new AccountForm());
        return "admin-users";
    }

    @PostMapping
    public String create(@ModelAttribute AccountForm form) {
        SysUser user = new SysUser();
        user.setUsername(form.getUsername());
        user.setPassword(form.getPassword());
        user.setEnabled(Boolean.TRUE.equals(form.getEnabled()));
        SysUser savedUser = userRepository.save(user);
        replaceUserRole(savedUser.getId(), form.getRoleId());
        return "redirect:/admin/users";
    }

    @GetMapping("/{id}/edit")
    public String edit(@PathVariable Long id, Authentication authentication, Model model) {
        SysUser user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("账号不存在：" + id));
        AccountForm form = new AccountForm();
        form.setId(user.getId());
        form.setUsername(user.getUsername());
        form.setPassword(user.getPassword());
        form.setEnabled(user.getEnabled());
        roleRepository.findRolesByUsername(user.getUsername()).stream()
                .findFirst()
                .map(SysRole::getId)
                .ifPresent(form::setRoleId);
        addModel(authentication, model, form);
        return "admin-users";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable Long id, @ModelAttribute AccountForm form) {
        SysUser user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("账号不存在：" + id));
        user.setUsername(form.getUsername());
        user.setPassword(form.getPassword());
        user.setEnabled(Boolean.TRUE.equals(form.getEnabled()));
        userRepository.save(user);
        replaceUserRole(id, form.getRoleId());
        return "redirect:/admin/users";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, Authentication authentication) {
        SysUser user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("账号不存在：" + id));
        if (!authentication.getName().equals(user.getUsername())) {
            jdbcTemplate.update("delete from sys_user_role where user_id = ?", id);
            userRepository.deleteById(id);
        }
        return "redirect:/admin/users";
    }

    private void addModel(Authentication authentication, Model model, AccountForm form) {
        if (form.getRoleId() == null) {
            roleRepository.findByName("ROLE_STUDENT").map(SysRole::getId).ifPresent(form::setRoleId);
        }
        List<AccountRow> users = userRepository.findAll().stream()
                .map(user -> new AccountRow(user, roleRepository.findRolesByUsername(user.getUsername())))
                .collect(Collectors.toList());
        model.addAttribute("users", users);
        model.addAttribute("roles", roleRepository.findAll());
        model.addAttribute("accountForm", form);
        model.addAttribute("username", authentication.getName());
        model.addAttribute("formAction", form.getId() == null ? "/admin/users" : "/admin/users/" + form.getId());
    }

    private void replaceUserRole(Long userId, Long roleId) {
        jdbcTemplate.update("delete from sys_user_role where user_id = ?", userId);
        if (roleId != null) {
            jdbcTemplate.update("insert into sys_user_role (user_id, role_id) values (?, ?)", userId, roleId);
        }
    }

    public static class AccountRow {
        private final SysUser user;
        private final String roleText;

        public AccountRow(SysUser user, List<SysRole> roles) {
            this.user = user;
            this.roleText = roles.stream().map(SysRole::getDescription).collect(Collectors.joining(", "));
        }

        public SysUser getUser() {
            return user;
        }

        public String getRoleText() {
            return roleText;
        }
    }

    public static class AccountForm {
        private Long id;
        private String username;
        private String password = "123";
        private Boolean enabled = true;
        private Long roleId;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public Boolean getEnabled() {
            return enabled;
        }

        public void setEnabled(Boolean enabled) {
            this.enabled = enabled;
        }

        public Long getRoleId() {
            return roleId;
        }

        public void setRoleId(Long roleId) {
            this.roleId = roleId;
        }
    }
}
